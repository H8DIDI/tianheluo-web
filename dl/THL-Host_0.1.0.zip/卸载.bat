@echo off
chcp 65001 >nul
set "DEST=%APPDATA%\Autodesk\Revit\Addins\2026"
tasklist | find /i "Revit.exe" >nul
if not errorlevel 1 (
  echo   请先关闭 Revit，再运行本文件。
  pause
  exit /b 1
)
del /q "%DEST%\THL.addin" 2>nul
rmdir /s /q "%DEST%\THL" 2>nul
echo   宿主已卸载。已安装的插件仍保留在 %APPDATA%\Tianheluo，如需清除请手动删除该文件夹。
pause
