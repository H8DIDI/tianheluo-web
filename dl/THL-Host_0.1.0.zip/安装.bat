@echo off
chcp 65001 >nul
title 天河落 安装
set "DEST=%APPDATA%\Autodesk\Revit\Addins\2026"
echo.
echo   天河落 THL —— Revit 2026 插件宿主
echo   即将安装到：%DEST%
echo.
tasklist | find /i "Revit.exe" >nul
if not errorlevel 1 (
  echo   [!] 检测到 Revit 正在运行，请先关闭 Revit，再重新双击本文件。
  echo.
  pause
  exit /b 1
)
if not exist "%DEST%" mkdir "%DEST%"
if not exist "%DEST%\THL" mkdir "%DEST%\THL"
copy /y "%~dp0THL.addin" "%DEST%\" >nul || goto fail
copy /y "%~dp0THL\THL.Host.dll" "%DEST%\THL\" >nul || goto fail
echo   安装完成！
echo   下一步：打开 Revit 2026，顶部会出现「天河落」选项卡。
echo   首次打开时 Revit 会问是否加载，请选「始终加载」。
echo.
pause
exit /b 0
:fail
echo   [!] 复制失败，请把本文件夹完整解压后再试，或右键以管理员身份运行。
pause
exit /b 1
